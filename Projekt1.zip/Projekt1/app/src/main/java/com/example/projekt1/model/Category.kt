package com.example.projekt1.model

enum class Category {
    Produkty_Spozywcze,
    Leki,
    Kosmetyki
}