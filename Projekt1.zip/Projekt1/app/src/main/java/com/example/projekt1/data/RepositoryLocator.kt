package com.example.projekt1.data

object RepositoryLocator {
    val foodRepository: FoodRepository = FoodRepositoryInMemory
}